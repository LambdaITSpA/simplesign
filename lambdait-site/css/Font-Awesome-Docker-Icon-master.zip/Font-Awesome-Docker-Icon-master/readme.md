# Docker icon for font awesome

Usage:

	<i class="fa fa-docker"></i>

![](http://wes.io/Vfcs/content)
